export const paymentService = {
  async getAll() {
    // Example service logic
    return [{ message: 'Service logic here' }];
  },
};
