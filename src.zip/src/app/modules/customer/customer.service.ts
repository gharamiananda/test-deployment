export const customerService = {
  async getAll() {
    // Example service logic
    return [{ message: 'Service logic here' }];
  },
};
