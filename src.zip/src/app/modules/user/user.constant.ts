export const UserSearchableFields = [
    'email',
    'name',
    'role'
];